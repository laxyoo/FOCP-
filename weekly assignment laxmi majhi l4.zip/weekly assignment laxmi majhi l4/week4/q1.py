def validate_input(value):

    return 0 <= value <= 100

# Short program to test the function
def test_validate_input():
    print("Enter a number to validate if it's in the range 0 to 100 (inclusive).")
    try:
        user_input = int(input("Enter an integer: "))
        if validate_input(user_input):
            print(f"{user_input} is within the range 0 to 100.")
        else:
            print(f"{user_input} is out of range.")
    except ValueError:
        print("Invalid input. Please enter an integer.")

# Run the test program
test_validate_input()

