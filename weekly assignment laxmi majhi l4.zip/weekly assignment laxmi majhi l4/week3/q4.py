def check_password_requirements(password):
    """
    Checks if the password meets all the specified requirements.
    Returns True if all requirements are met, otherwise False.
    """
    if len(password) < 8:
        print("Password must be at least 8 characters long.")
        return False
    if not any(char.isdigit() for char in password):
        print("Password must contain at least one digit.")
        return False
    if not any(char.isupper() for char in password):
        print("Password must contain at least one uppercase letter.")
        return False
    if not any(char.islower() for char in password):
        print("Password must contain at least one lowercase letter.")
        return False
    if not any(char in "!@#$%^&*()-_+=<>?/." for char in password):
        print("Password must contain at least one special character (e.g., !, @, #, $, etc.).")
        return False
    return True


def main():
    """
    Continuously asks the user for a password until it passes all checks.
    """
    while True:
        password = input("Enter a password: ")
        if check_password_requirements(password):
            print("Password successfully set!")
            break
        else:
            print("Please try again.\n")


# Run the program
main()
