def manage_countries():
    # Dictionary to store countries and their capitals
    countries = {
        "nepal": "Kathmandu",
        "japan": "tokyo",
        "india": "delhi",
        "italy": "rome",
        "spain": "madrid"
    }

    print("Welcome to the Country Capital Manager!")
    print("Type 'exit' to terminate the program.")

    while True:
        # Prompt user to enter a country name
        country = input("\nEnter a country name: ").strip().lower()

        # Terminate if the user types 'exit'
        if country == 'exit':
            print("Goodbye!")
            break

        # Check if the country is known
        if country in countries:
            print(f"The capital of {country.capitalize()} is {countries[country].capitalize()}.")
        else:
            # If the country is not known, ask the user to provide its capital
            capital = input(f"I don't know the capital of {country.capitalize()}. Please enter it: ").strip().lower()
            countries[country] = capital
            print(f"Thanks! The capital of {country.capitalize()} is now {capital.capitalize()}.")

if __name__ == "__main__":
    manage_countries()
