from collections import Counter

def frequency_analysis(encrypted_text):
    # Count the occurrences of each symbol in the encrypted text
    frequency = Counter(encrypted_text)
    
    # Sort symbols by frequency in descending order
    sorted_frequency = sorted(frequency.items(), key=lambda x: x[1], reverse=True)
    
    # Display the frequency table
    print("Symbol\tFrequency")
    for symbol, freq in sorted_frequency:
        print(f"{symbol}\t{freq}")
    
    return sorted_frequency

# Example usage
encrypted_text = "gsv jfrxp yildm ulc qfnkh levi gsv ozab wlt"
print("Encrypted text:", encrypted_text)
print("\nFrequency Analysis:")
freq_analysis = frequency_analysis(encrypted_text)

# Display symbols in order of decreasing frequency
most_common_symbols = [symbol for symbol, freq in freq_analysis]
print("\nSymbols in order of frequency (most to least):")
print(most_common_symbols)
