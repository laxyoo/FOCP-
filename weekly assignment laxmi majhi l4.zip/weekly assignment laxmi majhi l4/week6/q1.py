def to_binary(number):
    if number <= 0:
         ValueError("The number must be a positive integer.")
    return bin(number)[2:]
try:
    num = int(input("Enter a positive integer: "))
    print(f"The binary representation of {num} is {to_binary(num)}")
except ValueError as e:
    print(e)
