
def find_factors(number):
    if number == 0:
        return [0]  
    factors = []
    for i in range(1, abs(number) + 1):
        if number % i == 0:
            factors.append(i)
    return factors
def test_find_factors():
    print("Factors of 10:", find_factors(10))
    print("Factors of -10:", find_factors(-10))  
    print("Factors of 7:", find_factors(7))  
    print("Factors of 0:", find_factors(0))
    print("Factors of 6:", find_factors(6))
    print("Factors of 9:", find_factors(9))
test_find_factors()
